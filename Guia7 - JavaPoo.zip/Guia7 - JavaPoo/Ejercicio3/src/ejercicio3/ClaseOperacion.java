/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio3;

/**
 *
 * @author Usuario
 */
public class ClaseOperacion {

    public int getNum1() {
        return num1;
    }

    public void setNum1(int num1) {
        this.num1 = num1;
    }

    public int getNum2() {
        return num2;
    }

    public void setNum2(int num2) {
        this.num2 = num2;
    }

    public ClaseOperacion() {
    }

    public ClaseOperacion(int num1) {
        this.num1 = num1;
    }
    private int num1;
    private int num2;
       
} 



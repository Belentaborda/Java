/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej6extrapoo;

import Servicios.AhorcadoServicios;

/**
 *
 * @author usuario
 */
public class Ej6ExtraPoo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        AhorcadoServicios juegoS = new AhorcadoServicios();
        juegoS.juego();
        
       
    }
    
}
